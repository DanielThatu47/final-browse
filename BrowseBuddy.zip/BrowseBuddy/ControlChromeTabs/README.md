<p align="center">
    <img alt="" height="80" src="./img/chrome_logo_PNG33.png">
  </a>
</p>
<h1 align="center">Control Chrome Tabs</h1>

<div align="center">
  Close all tab with a single click
</div>

<br />

<div align="center">
  <!-- Standard -->
  <a href="https://standardjs.com">
    <img src="https://img.shields.io/badge/code%20style-standard-brightgreen.svg?style=flat-square"
      alt="Standard" />
  </a>
</div>

## ⚡️  Introduction
Control Chrome Tabs helps you to close all the unnecessary tabs of our browser with a single click


## Tech Stack used:
* JavaScript

## 📷 Screenshots

![ss1](./img/000001.png)
![ss2](./img/000002.png)

## ‎‍💻 Authors

- [@iamrahulmahato](https://www.github.com/iamrahulmahato)
## ⭐️ Show your support

Give a star if this project helped you!
