# List all tabs Extension
Display all tabs as a list, with filter.
This extention allows easy switching tabs, toggle mute/unmute a tab and closing it.

## installation instuctions

### Install from the chrome store: https://chrome.google.com/webstore/detail/list-all-tabs/iklkoalaepbjckknpnklbipmplnipcid  


---

**Change Log** - [Change log](CHANGELOG.MD)

---
### Contributors:

Lior Shtivelman <lior99apps@gmail.com>



