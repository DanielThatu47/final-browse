# QR-Generator-Chrome-Extension
Paste anything to generate a QR code for it 
